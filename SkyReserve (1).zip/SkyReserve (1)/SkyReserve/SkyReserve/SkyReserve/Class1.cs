﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SkyReserve
{
    class FlightSearch
    {
        public static string sourceAirportID;
        public static string destAirportID;
        public static DateTime selectedDate;
    }
}
